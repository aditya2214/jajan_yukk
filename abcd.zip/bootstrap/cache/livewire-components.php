<?php return array (
  'component.master.footer-bar' => 'App\\Http\\Livewire\\Component\\Master\\FooterBar',
  'component.master.homeslider' => 'App\\Http\\Livewire\\Component\\Master\\Homeslider',
  'component.master.index' => 'App\\Http\\Livewire\\Component\\Master\\Index',
  'component.master.maincontent' => 'App\\Http\\Livewire\\Component\\Master\\Maincontent',
  'component.master.mainmenu' => 'App\\Http\\Livewire\\Component\\Master\\Mainmenu',
  'component.master.ourclient' => 'App\\Http\\Livewire\\Component\\Master\\Ourclient',
  'component.master.pesan' => 'App\\Http\\Livewire\\Component\\Master\\Pesan',
  'component.master.topbar' => 'App\\Http\\Livewire\\Component\\Master\\Topbar',
  'component.toko.edit-profil-toko' => 'App\\Http\\Livewire\\Component\\Toko\\EditProfilToko',
  'component.toko.home' => 'App\\Http\\Livewire\\Component\\Toko\\Home',
  'component.toko.katalog-produk' => 'App\\Http\\Livewire\\Component\\Toko\\KatalogProduk',
  'component.toko.produk' => 'App\\Http\\Livewire\\Component\\Toko\\Produk',
);