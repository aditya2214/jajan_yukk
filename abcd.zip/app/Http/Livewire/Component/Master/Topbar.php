<?php

namespace App\Http\Livewire\Component\Master;

use Livewire\Component;

class Topbar extends Component
{
    public function render()
    {
        return view('livewire.component.master.topbar');
    }
}
