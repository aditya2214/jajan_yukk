<?php

namespace App\Http\Livewire\Component\Master;

use Livewire\Component;

class Ourclient extends Component
{
    public function render()
    {
        return view('livewire.component.master.ourclient');
    }
}
