<?php

namespace App\Http\Livewire\Component\Master;

use Livewire\Component;

class FooterBar extends Component
{
    public function render()
    {
        return view('livewire.component.master.footer-bar');
    }
}
