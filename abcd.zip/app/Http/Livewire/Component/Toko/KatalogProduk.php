<?php

namespace App\Http\Livewire\Component\Toko;

use Livewire\Component;

class KatalogProduk extends Component
{
    public function render()
    {
        return view('livewire.component.toko.katalog-produk');
    }
}
