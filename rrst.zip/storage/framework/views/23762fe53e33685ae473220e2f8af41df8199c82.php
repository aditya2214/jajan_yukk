<div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                    <!-- <div class="btn-group" role="group" aria-label="Basic example"> -->
                        <button wire:click="menuitem2" class="btn btn-outline-primary btn-sm">Katalog</button>
                        <button wire:click="menuitem3"  class="btn btn-outline-primary btn-sm">Edit Profil Toko
                        </button>
                        <div wire:loading wire:target="menuitem3"> 
                                Mohon Tunggu...
                        </div>
                        <div wire:loading wire:target="menuitem2"> 
                                Mohon Tunggu...
                        </div>
                    <!-- </div> -->
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <?php if($menu_item == 2): ?>
                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('component.toko.produk', [])->html();
} elseif ($_instance->childHasBeenRendered('saLD9vB')) {
    $componentId = $_instance->getRenderedChildComponentId('saLD9vB');
    $componentTag = $_instance->getRenderedChildComponentTagName('saLD9vB');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('saLD9vB');
} else {
    $response = \Livewire\Livewire::mount('component.toko.produk', []);
    $html = $response->html();
    $_instance->logRenderedChild('saLD9vB', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:component.toko.produk>
                                <?php elseif($menu_item == 3): ?>
                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('component.toko.edit-profil-toko', [])->html();
} elseif ($_instance->childHasBeenRendered('E9rtpST')) {
    $componentId = $_instance->getRenderedChildComponentId('E9rtpST');
    $componentTag = $_instance->getRenderedChildComponentTagName('E9rtpST');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('E9rtpST');
} else {
    $response = \Livewire\Livewire::mount('component.toko.edit-profil-toko', []);
    $html = $response->html();
    $_instance->logRenderedChild('E9rtpST', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:component.toko.edit-profil-toko>
                                <?php else: ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\jajan_yukk\resources\views/livewire/component/toko/home.blade.php ENDPATH**/ ?>