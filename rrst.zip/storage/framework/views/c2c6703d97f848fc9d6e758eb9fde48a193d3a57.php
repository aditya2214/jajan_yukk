<div>
    <strong>Mitra</strong>
</div><?php /**PATH C:\xampp\htdocs\jajan_yukk\resources\views/livewire/component/master/ourclient.blade.php ENDPATH**/ ?>