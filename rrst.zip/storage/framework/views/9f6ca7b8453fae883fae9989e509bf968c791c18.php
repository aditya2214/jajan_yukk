<div>
    <div class="container">
      <div class="card"style="border-radius:20px;">
        <div class="card-body">
          <h1 style="font-family: 'Sofia', sans-serif">Insta kuliner</h1>
          <small>Instagram Kuliner <a target="_blank" href="https://id.wikipedia.org/wiki/Cilamaya_Wetan,_Karawang"><u><i>cilamaya wetan</i></u></a></small>
        </div>
      </div>
      <!-- <p class="lead text-muted">Semua jajanan di cilamaya wetan hadir di sini... tunggu apa lagi buruan pesan</p>
      <p>
        <a href="#" class="btn btn-primary my-2">Main call to action</a>
        <a href="#" class="btn btn-secondary my-2">Secondary action</a>
      </p> -->
      <!-- <br> -->
      
    </div>
</div><?php /**PATH C:\xampp\htdocs\jajan_yukk\resources\views/livewire/component/master/homeslider.blade.php ENDPATH**/ ?>