<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('component.toko.home', [])->html();
} elseif ($_instance->childHasBeenRendered('Gm4PQjk')) {
    $componentId = $_instance->getRenderedChildComponentId('Gm4PQjk');
    $componentTag = $_instance->getRenderedChildComponentTagName('Gm4PQjk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Gm4PQjk');
} else {
    $response = \Livewire\Livewire::mount('component.toko.home', []);
    $html = $response->html();
    $_instance->logRenderedChild('Gm4PQjk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:component.toko.home>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jajan_yukk\resources\views/home.blade.php ENDPATH**/ ?>