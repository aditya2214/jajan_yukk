<div>
    <div class="card">
        <div class="card-body">
            <strong>Silahkan Pilih Kurir</strong>
            <table class="table table-bordered">
                <thead class="thead-dark">
                    <th>Nama</th>
                    <!-- <th>Alamat</th> -->
                    <th>Telpon</th>
                    <th>WA</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $kurirs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kurir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($kurir->Nama); ?></td>
                        <!-- <td><?php echo e($kurir->Alamat); ?></td> -->
                        <td><?php echo e($kurir->Telp); ?></td>
                        <td>
                            <a href="" class="btn btn-success btn-sm" style="border-radius:100px;" >
                                <i class="fab fa-whatsapp" style="font-size: 30px;"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\jajan_yukk\resources\views/livewire/component/master/pesan.blade.php ENDPATH**/ ?>