<div>
    <div class="container">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('component.master.ourclient', [])->html();
} elseif ($_instance->childHasBeenRendered('Fdy4lAX')) {
    $componentId = $_instance->getRenderedChildComponentId('Fdy4lAX');
    $componentTag = $_instance->getRenderedChildComponentTagName('Fdy4lAX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Fdy4lAX');
} else {
    $response = \Livewire\Livewire::mount('component.master.ourclient', []);
    $html = $response->html();
    $_instance->logRenderedChild('Fdy4lAX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:component.master.ourclient>
    <p class="float-right">
      <a class="btn btn-secondary" href="#">Kembali ke atas&nbsp;<i class="fas fa-arrow-up"></i></a>
    </p>
    <p>Istakuliner adalah  &copy; Perusahaan yang bergerak dibidang e-commerce yang dapat mengubungkan pengguna dengan kurir dengan ongkos kirim serba Rp.1000</p>
    <p>Di Buat Oleh <strong> Aditya Oktaviana </strong></p>
  </div>
  <br><br><br>
</div><?php /**PATH C:\xampp\htdocs\jajan_yukk\resources\views/livewire/component/master/footer-bar.blade.php ENDPATH**/ ?>