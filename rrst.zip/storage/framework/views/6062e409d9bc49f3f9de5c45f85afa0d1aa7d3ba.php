<div>
    <header>
		<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('component.master.mainmenu', [])->html();
} elseif ($_instance->childHasBeenRendered('ju8tvmb')) {
    $componentId = $_instance->getRenderedChildComponentId('ju8tvmb');
    $componentTag = $_instance->getRenderedChildComponentTagName('ju8tvmb');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ju8tvmb');
} else {
    $response = \Livewire\Livewire::mount('component.master.mainmenu', []);
    $html = $response->html();
    $_instance->logRenderedChild('ju8tvmb', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:component.master.mainmenu>
	</header>

	<main role="main">

	<section class="jumbotron text-center">
		<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('component.master.homeslider', [])->html();
} elseif ($_instance->childHasBeenRendered('CKd2Pq8')) {
    $componentId = $_instance->getRenderedChildComponentId('CKd2Pq8');
    $componentTag = $_instance->getRenderedChildComponentTagName('CKd2Pq8');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('CKd2Pq8');
} else {
    $response = \Livewire\Livewire::mount('component.master.homeslider', []);
    $html = $response->html();
    $_instance->logRenderedChild('CKd2Pq8', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:component.master.homeslider>
	</section>

	<div class="album py-5 bg-light">
		<div class="container">

            <?php if($pesanan): ?>
            <button wire:click="kembali" class="btn btn-danger btn-sm">Kembali</button>

            <div>
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="card">
                                    <div class="card-body">
                                        <img src="<?php echo e(asset('myfiles/'.$img )); ?>" style="width:200px;display:block;margin-left:auto;margin-right:auto;" alt="">
                                        <p>Pesanan Anda : <strong><?php echo e($nama_produk); ?></strong></p> 
                                        
                                        <p>Harga    : <small>Rp<?php echo e(number_format($harga+1000)); ?></small></p>
                                    </div>
                                    <div class="card-footer">
                                        <p>Penjual : <strong><?php echo e($toko); ?></strong></p>
                                        <br><br>
                                        <p>Pesan Anda</p>
                                        <textarea wire:model="jumbel" placeholder="Contoh:Jumlah 2 rasa daun jeruk" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>                                   
                                     </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <strong>Silahkan Pilih Kurir</strong>
                        <table class="table table-bordered">
                            <thead class="thead-dark">
                                <th>Nama</th>
                                <th>Telpon</th>
                                <th>WA</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $kurirs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kurir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($kurir->Nama); ?></td>
                                    <td><?php echo e($kurir->Telp); ?></td>
                                    <td>
                                        <a href="https://wa.me/<?php echo e($kurir->Telp); ?>?text=Tolong Antarkan Pesanan Saya *<?php echo e($nama_produk); ?>* di *<?php echo e($toko); ?>* ini Keterangannya *<?php echo e($jumbel); ?>* Terimakasi. Ini Alamat saya .................Tuliskan Alamat Anda................" class="btn btn-success btn-sm" style="border-radius:100px;" >
                                            <i class="fab fa-whatsapp" style="font-size: 30px;"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php else: ?>
			<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('component.master.maincontent', [])->html();
} elseif ($_instance->childHasBeenRendered('12hV3xG')) {
    $componentId = $_instance->getRenderedChildComponentId('12hV3xG');
    $componentTag = $_instance->getRenderedChildComponentTagName('12hV3xG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('12hV3xG');
} else {
    $response = \Livewire\Livewire::mount('component.master.maincontent', []);
    $html = $response->html();
    $_instance->logRenderedChild('12hV3xG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:component.master.maincontent>
            <?php endif; ?>
        </div>
	</div>

	</main>

	<footer class="text-muted">
		<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('component.master.footer-bar', [])->html();
} elseif ($_instance->childHasBeenRendered('42e52tq')) {
    $componentId = $_instance->getRenderedChildComponentId('42e52tq');
    $componentTag = $_instance->getRenderedChildComponentTagName('42e52tq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('42e52tq');
} else {
    $response = \Livewire\Livewire::mount('component.master.footer-bar', []);
    $html = $response->html();
    $_instance->logRenderedChild('42e52tq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:component.master.footer-bar>
	</footer>
</div>
<?php /**PATH C:\xampp\htdocs\jajan_yukk\resources\views/livewire/component/master/index.blade.php ENDPATH**/ ?>