@extends('layouts.app')

@section('content')
<livewire:component.toko.home></livewire:component.toko.home>
@endsection
