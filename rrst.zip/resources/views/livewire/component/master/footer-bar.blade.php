<div>
    <div class="container">
    <livewire:component.master.ourclient></livewire:component.master.ourclient>
    <p class="float-right">
      <a class="btn btn-secondary" href="#">Kembali ke atas&nbsp;<i class="fas fa-arrow-up"></i></a>
    </p>
    <p>Istakuliner adalah  &copy; Perusahaan yang bergerak dibidang e-commerce yang dapat mengubungkan pengguna dengan kurir dengan ongkos kirim serba Rp.1000</p>
    <p>Di Buat Oleh <strong> Aditya Oktaviana </strong></p>
  </div>
  <br><br><br>
</div>