<div>
    <strong>Mitra</strong>
</div>